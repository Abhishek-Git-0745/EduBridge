package com.project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainApplication {
	private static Connection conn;
	private static Statement stmt;
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) throws SQLException {
		conn = DatabaseConn.getConncetion();
		stmt = conn.createStatement();
		int fstchoice,loginchoice;
		System.out.println("  -----------<o> AirLine Reservation Portal <o>-----------");
		for(;;) {
			System.out.println("\t+---------------------------------------+");
		System.out.println("\t|\t1.Register\t\t\t|\n\t|\t2.Login(Already have Account)\t|");
		System.out.println("\t+---------------------------------------+");
		fstchoice = sc.nextInt();
		switch(fstchoice) {
		case 1:
			System.out.print("\tEnter Username :");
			String uname = sc.next();
			System.out.print("\tEnter Email id : ");
			String email = sc.next();
			if (isValidEmail(email)) {
				System.out.print("\tEnter Password : ");
				String rpass = sc.next();
				System.out.print("\tRe-enter Password : ");
				String rrpass = sc.next();
				if(rpass.equals(rrpass)) {
					String query = "select * from login where username = '"+uname+"'";
					ResultSet rs = stmt.executeQuery(query);
					if(rs.next()) {
						System.out.println("User Already Exists");
					}else {
						String insert = "insert into login values('"+uname+"','"+email+"','"+rpass+"')";
						int i = stmt.executeUpdate(insert);
						if(i>0) {
							System.out.println("\t\t+--------------------------+");
							System.out.println("\t\t| Registered Successfully! |");
							System.out.println("\t\t+--------------------------+");
						}else {
							System.out.println("\t\t+--------------------+");
							System.out.println("\t\t| Registered Failed! |");
							System.out.println("\t\t+--------------------+");
						}
					}
				}else {
					System.out.println("Password incorrect!");
				}
	        } else {
	            System.out.println("Invalid Email Address");
	        }
			
			break;
		case 2:
			System.out.println("\t\t+-----------------------+");
			System.out.println("\t\t|1.User \t2.Admin |");
			System.out.println("\t\t+-----------------------+");
			
			loginchoice = sc.nextInt();
			switch(loginchoice) {
			case 1://user
				System.out.print("\tEnter username : ");
				String name = sc.next();
				System.out.print("\tEnter password : ");
				String pass = sc.next();
				String ck = "select * from login where username = '"+name+"' and password = '"+pass+"'";
				ResultSet rs = stmt.executeQuery(ck);
				if(rs.next()) {
				DatabaseOperations.userOperation(name);
				}else {
					System.out.println("user not found");
				}
				
				
				break;
			case 2://admin
				System.out.print("\tEnter username : ");
				name = sc.next();
				System.out.print("\tEnter password : ");
				 pass = sc.next();
				 ck = "select * from login where username = '"+name+"' and password = '"+pass+"'";
				 rs = stmt.executeQuery(ck);
				if(rs.next()) {
					DatabaseOperations.adminOperation();
				}else {
					System.out.println("user not found");
				}
				DatabaseOperations.adminOperation();
				break;
			default:
				System.out.println("Enter valid Choice");
			}
			break;
		default:
			System.out.println("wrong choice");
			
		}
		}
		
	}

	private static boolean isValidEmail(String email) {
        // Define the regex pattern for a basic email validation
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

        // Create a Pattern object
        Pattern pattern = Pattern.compile(emailRegex);

        // Create a matcher object
        Matcher matcher = pattern.matcher(email);

        // Return true if the email matches the pattern
        return matcher.matches();
	}

}
