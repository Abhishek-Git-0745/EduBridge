package com.project;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Scanner;


public class DatabaseOperations {
	private static Connection conn;
	private static Statement stmt;
	private static String sql;
	private static PreparedStatement ps;
	private static ResultSet rs;
	private static Scanner sc = new Scanner(System.in);
	private static String dept=null,desti=null,status = null,Dateb = null,timeb=null;
	private static int flightid;
	private static Date date;
	private static Time time;
	private static String redColorCode = "\u001B[31m";
	private static String resetColorCode = "\u001B[0m";
	
	public static void userOperation(String name) throws SQLException{
		conn = DatabaseConn.getConncetion();
		stmt = conn.createStatement();
		for(;;) {
			System.out.println();
			System.out.println(">>>>>>>>>>o Enter Service You Want To Use o<<<<<<<<<<<");
			System.out.println();
			System.out.println("\t|=====================================|");       
			System.out.println("\t|  1.Flight Book  2.Flight Cancel     |");      
			System.out.println("\t|  3.Flight Info  4.Flight TimeTable  |");
			System.out.println("\t| \t\t5.Exit                |");
			System.out.println("\t|=====================================|");
		
		int ch = sc.nextInt();
		switch (ch) {
		case 1:
			
			System.out.print("\tEnter departure : ");
			String deptcity = sc.next();
			System.out.print("\tEnter Destination : ");
			String destcity = sc.next();
//			System.out.println("Enter Departure Date (YYYY-MM-DD)");
//			Dateb = sc.next();
			
			String checkav = "select * from timetable where dept = '"+deptcity+"' and desti = '"+destcity+"' and status='Available'";
			
			
			ResultSet r = stmt.executeQuery(checkav);
			flightid = 0;
			if(!r.next()) {
				System.out.println("\tFlight not available form "+deptcity+" to "+destcity);
				break;			
			}
			System.out.println("\t+------+-------+-------+------------+----------+------------+");
			System.out.println("\t| Fl-id| dept  | desti |  status    |   time   |    date    |");
			System.out.println("\t+------+-------+-------+------------+----------+------------+");
			ResultSet rs = stmt.executeQuery(checkav);
			while(rs.next()) {
				
			    flightid = rs.getInt(1);
			    dept = rs.getString(2);
			    desti = rs.getString(3);
			    date = rs.getDate(4);
			    time = rs.getTime(5);
			    status = rs.getString(6);

			    String formattedOutput = String.format("\t| %-4d | %-5s | %-5s | %-10s | %-8tT | %-5tF |", flightid, dept, desti, status, time, date);
			    System.out.println(formattedOutput);	
			    System.out.println("\t+------+-------+-------+------------+----------+------------+");

			}
			
			
			System.out.println("Enter Flight id : ");
			int userFlight = sc.nextInt();
			stmt = conn.createStatement();
			sql = "insert into bookings"
					+ "(fl_id,uname,dept,desti,date,status) values"
					+ "("+userFlight+", '"+name+"','"+deptcity+"','"+destcity+"','"+date+"','active')";
			int i=stmt.executeUpdate(sql);
			
			if(i>0) {
				System.out.println("Flight added");
			}else {
				System.out.println("error occured");
			}
			break;
		case 2:
			
			String query = "select * from bookings where uname = '"+name+"' and status = 'active'";
			rs = stmt.executeQuery(query);
			if(!rs.next()) {
				System.out.println("Data not available to delete");
				break;
			}
			 r = stmt.executeQuery(query);
			 	System.out.println("\t+------+-------+--------+------------+");
		        System.out.println("\t|fl_id | dept  | desti  |    date    |");
		        System.out.println("\t+------+-------+--------+------------+");
			while(r.next()) {
				dept = r.getString(3);
				desti = r.getString(4);
				flightid = r.getInt(2);
				date = r.getDate(5);
			    System.out.printf("\t|%-6d| %-6s| %-7s| %-11tF|\n", flightid, dept, desti, date);
			    System.out.println("\t+------+-------+--------+------------+");
			}
			if(flightid<=0) {
				System.out.println("Data not available to delete");
			}
			System.out.print("\tEnter flight id to cancel..");
			int idc = sc.nextInt();
			sql = "update bookings set status='cancelled' where fl_id ="+idc+"";
			int j = stmt.executeUpdate(sql);
			if(j>0) {
				System.out.println("\tBooking cancelled");
			}else {
				System.out.println("Data not available to delete");
			}
		
			break;
		case 3:
			sql = "select * from bookings";
			rs = stmt.executeQuery(sql);
			int id;
			Timestamp timestamp;
			System.out.println("\t+----+-------+---------+---------+------------+------------+-----------------------+");
	        System.out.println("\t| id | fl_id | dept    | desti   | status     | date       | timestamp             |");
	        System.out.println("\t+----+-------+---------+---------+------------+------------+-----------------------+");
	        

			while(rs.next()) {
				id = rs.getInt(1);
				dept = rs.getString(3);
				desti = rs.getString(4);
				flightid = rs.getInt(2);
				date = rs.getDate(5);
				status = rs.getString(6);
				timestamp = rs.getTimestamp(7);
				String formattedOutput = String.format("\t| %-2d | %-5d | %-7s | %-7s | %-10s | %-10tF | %-19s |",
	                    id, flightid, dept, desti, status, date, timestamp);
	            System.out.println(formattedOutput);
	            }
			System.out.println("\t+----+-------+---------+---------+------------+------------+-----------------------+");
            
			break;
		case 4:
//			 id  | dept     | desti    | date       | time     | status
			sql = "select * from timetable";
			rs= stmt.executeQuery(sql);
			
			System.out.println("\t+-------+-------+-------+---------------+---------------+-----------+");
			System.out.println("\t| id    | dept  | desti | date          | time          | status    |");
			System.out.println("\t+-------+-------+-------+---------------+---------------+-----------+");

			while(rs.next()) {
				dept = rs.getString(2);
				desti = rs.getString(3);
				flightid = rs.getInt(1);
				date = rs.getDate(4);
				time = rs.getTime(5);
				status = rs.getString(6);
				System.out.println("\t| " + flightid + "\t| " + dept + "\t| " + desti + "\t| " + date + "\t| " + time + "\t| " + status + " |");
				
			}
			System.out.println("\t+-------+-------+-------+---------------+---------------+-----------+");
			break;
		case 5:
			System.out.println("\tTHANK YOU! \n \tVISIT AGAIN");
			System.exit(0);
			break;
		default:
			System.out.println("please enter valid choice");
			break;
		}
		}
		
		
	}


	public static void adminOperation() throws SQLException {
		conn = DatabaseConn.getConncetion();
		stmt = conn.createStatement();
		for(;;) {
		System.out.println("\t+-----------------------------------------+");
		System.out.println("\t| 1.Scedule a flight\t2.Update a flight |");
		System.out.println("\t| 3.Check Bookings  \t4.TimeTable       |");
		System.out.println("\t|                 5.Exit                  |");
		System.out.println("\t+-----------------------------------------+");
		int ch = sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("add following details squentially");
			System.out.print("\tid  : ");
			flightid = sc.nextInt();
			System.out.print("\tdept : ");
			dept = sc.next();
			System.out.print("\tdesti : ");
			desti = sc.next();
			System.out.print("\tdate : ");
			Dateb = sc.next();
			System.out.print("\ttime : ");
			timeb = sc.next();
			System.out.print("\tstatus : ");
			status = sc.next();
			String sql = "INSERT INTO timetable VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);

			preparedStatement.setInt(1, flightid);
			preparedStatement.setString(2, dept);
			preparedStatement.setString(3, desti);
			preparedStatement.setString(4, Dateb);
			preparedStatement.setString(5, timeb);
			preparedStatement.setString(6, status);

			int i = preparedStatement.executeUpdate();
			if(i>0) {
				System.out.println("\n\t<--(( Flight added successfully ))-->");
			}else {
				System.out.println("\n\t[]-> Re-enter details, failed to add a flight <-[]");
			}
			
			break;
		case 2:
			String qry = "select * from timetable";
			rs = stmt.executeQuery(qry);
//			System.out.println("id\tdept\tdesti\tdate\t\ttime\t\tstatus");
			System.out.print("Available Flight IDs: ");
			while (rs.next()) {
			    flightid = rs.getInt(1);
			    System.out.print(flightid + " ");
			}
			System.out.println();
			System.out.println("Enter flight id where you want to update:");
			flightid = sc.nextInt();
			qry = "select * from timetable where id ="+flightid+"";
			rs = stmt.executeQuery(qry);
			System.out.println("id\tdept\tdesti\tdate\t\ttime\t\tstatus");
			while(rs.next()) {
				flightid = rs.getInt(1);
				dept = rs.getString(2);
				desti = rs.getString(3);
				date = rs.getDate(4);
				time = rs.getTime(5);
				status = rs.getString(6);
				System.out.println(flightid+"\t"+dept+"\t"+desti+"\t"+date+"\t"+time+"\t"+status);
			}
			System.out.println();
			System.out.println("Enter which field you want to update:");
			String upfld = sc.next();

			System.out.println("Enter new value for " + upfld + ":");
			String updata = sc.next();

			sql = "UPDATE timetable SET " + upfld + "='" + updata + "' WHERE id=" + flightid;
			 i = stmt.executeUpdate(sql);
			if(i>0) {
				System.out.println("data updated");
			}else {
				System.out.println("error occured");
			}
			break;
		case 3:
			sql = "select * from bookings where status = 'active'";
			System.out.println("\t+------+-------+-------+------------+----------+------------+");
			System.out.println("\t| Fl-id| dept  | desti |  status    |   time   |    date    |");
			System.out.println("\t+------+-------+-------+------------+----------+------------+");
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				
			    flightid = rs.getInt(2);
			    dept = rs.getString(3);
			    desti = rs.getString(4);
			    date = rs.getDate(5);
			    time = rs.getTime(7);
			    status = rs.getString(6);

			    String formattedOutput = String.format("\t| %-4d | %-5s | %-5s | %-10s | %-8tT | %-5tF |", flightid, dept, desti, status, time, date);
			    System.out.println(formattedOutput);	
			    System.out.println("\t+------+-------+-------+------------+----------+------------+");

			}
			
			break;
		case 4:
			sql = "select * from timetable";
			rs= stmt.executeQuery(sql);
			
			System.out.println("\t+-------+-------+-------+---------------+---------------+-----------+");
			System.out.println("\t| id    | dept  | desti | date          | time          | status    |");
			System.out.println("\t+-------+-------+-------+---------------+---------------+-----------+");

			while(rs.next()) {
				dept = rs.getString(2);
				desti = rs.getString(3);
				flightid = rs.getInt(1);
				date = rs.getDate(4);
				time = rs.getTime(5);
				status = rs.getString(6);
				System.out.println("\t| " + flightid + "\t| " + dept + "\t| " + desti + "\t| " + date + "\t| " + time + "\t| " + status + " |");
				
			}
			System.out.println("\t+-------+-------+-------+---------------+---------------+-----------+");
			break;
		case 5:
			System.exit(0);
			break;
		default:
			System.out.println("wrong choice");
			break;
		}
		}
		
	}

}
