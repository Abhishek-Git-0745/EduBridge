package com.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConn {

	private static String drivers = "com.mysql.cj.jdbc";
	private static String url = "jdbc:mysql://localhost:3306/10426_ARS";
	private static String uname = "root";
	private static String pass = "Abhishek683";
	
	private static Connection conn = null;
	
	public static Connection getConncetion() throws SQLException{
		
		if(conn==null)
				conn = DriverManager.getConnection(url,uname,pass);
		
		return conn;
		
	}
	

}
